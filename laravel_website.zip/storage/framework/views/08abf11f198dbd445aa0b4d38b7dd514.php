<?php if(isset($respuesta)): ?>
    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($resp->idUsability); ?>">
            <td><?php echo e($resp->name); ?></td>
            <td class="button_actions">
                <a href="<?php echo e(route('usabilities.edit',$resp->idUsability)); ?>" class="btn btn-success">Editar</a>
                <button class='btnBorrar btn btn-danger' type='submit' form="delete_<?php echo e($resp->idUsability); ?>" onclick="return confirm('¿Estás seguro de eliminar el registro?')">Borrar</button>
                <form action="<?php echo e(route('usabilities.destroy',$resp->idUsability)); ?>" method ="POST" id="delete_<?php echo e($resp->idUsability); ?>" enctype="multipart/form-data" hidden><!--method ="POST" -->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/livewire/usability-component.blade.php ENDPATH**/ ?>