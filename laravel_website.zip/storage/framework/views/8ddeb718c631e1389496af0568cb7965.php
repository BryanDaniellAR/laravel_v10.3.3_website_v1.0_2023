<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Number</label>
        <input type="text" class="form-control" name="number" value="<?php echo e((isset($respuesta))?$respuesta->data->number: old('number')); ?>" placeholder="Escribir el numero" maxlength="50" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Birthday</label>
        <input type="text" class="form-control" name="birthday" value="<?php echo e((isset($respuesta))?$respuesta->data->birthday: old('birthday')); ?>" placeholder="Escribir el cumpleaños" maxlength="100" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Description</label>
        <textarea type="text" class="form-control" name="description" aria-label="With textarea" placeholder="Escribir la descripción del perfil" maxlength="500" rows="4" required><?php echo e((isset($respuesta))?$respuesta->data->description: old('description')); ?></textarea>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Usuario</label>
        <select class="form-select filter-select" name="id" title="id" required>
            <option value="">Seleccionar un usuario</option>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->id == $respuesta->data->id): ?>
                        <option value="<?php echo e($resp->id); ?>" selected><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->id); ?>"><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->id); ?>"><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/profiles/partials/form.blade.php ENDPATH**/ ?>