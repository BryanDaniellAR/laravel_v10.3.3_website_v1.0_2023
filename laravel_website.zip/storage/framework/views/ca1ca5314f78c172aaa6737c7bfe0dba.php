<?php if(isset($respuesta)): ?>
    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($resp->idRol); ?>">
            <td><?php echo e($resp->description); ?></td>
            <td class="button_actions">
                <a href="<?php echo e(route('roles.edit',$resp->idRol)); ?>" class="btn btn-success">Editar</a>
                <button class='btnBorrar btn btn-danger' type='submit' form="delete_<?php echo e($resp->idRol); ?>" onclick="return confirm('¿Estás seguro de eliminar el registro?')">Borrar</button>
                <form action="<?php echo e(route('roles.destroy',$resp->idRol)); ?>" method ="POST" id="delete_<?php echo e($resp->idRol); ?>" enctype="multipart/form-data" hidden><!--method ="POST" -->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/livewire/role-component.blade.php ENDPATH**/ ?>