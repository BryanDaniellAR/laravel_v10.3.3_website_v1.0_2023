
<?php $__env->startSection('content'); ?>
    <div class="card mt-3" :init='loadPosts'><!-- wire:init="loadPosts"-->
        <div class="card-header d-inline-flex">
            <h5>Host</h5>
            <a href="<?php echo e(route('hosts.create')); ?>" class="btn btn-primary ms-auto" >Agregar</a>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="container-fluid container-tabla">
            
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Url</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('host-component')->html();
} elseif ($_instance->childHasBeenRendered('5Aemgm3')) {
    $componentId = $_instance->getRenderedChildComponentId('5Aemgm3');
    $componentTag = $_instance->getRenderedChildComponentTagName('5Aemgm3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5Aemgm3');
} else {
    $response = \Livewire\Livewire::mount('host-component');
    $html = $response->html();
    $_instance->logRenderedChild('5Aemgm3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Url</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/hosts/index.blade.php ENDPATH**/ ?>