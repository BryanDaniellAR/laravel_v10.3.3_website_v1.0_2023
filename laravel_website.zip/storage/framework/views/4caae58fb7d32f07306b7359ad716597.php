<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Description</label>
        <input type="text" class="form-control" name="description" value="<?php echo e((isset($respuesta))?$respuesta->data->description: old('description')); ?>" placeholder="Escribir la descripción del rol" maxlength="200" required>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/roles/partials/form.blade.php ENDPATH**/ ?>