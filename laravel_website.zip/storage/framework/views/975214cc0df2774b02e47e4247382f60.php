<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Url</label>
        <input type="text" class="form-control" name="url" value="<?php echo e((isset($respuesta))?$respuesta->data->url: old('url')); ?>" placeholder="Escribir la url" maxlength="200" required>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/hosts/partials/form.blade.php ENDPATH**/ ?>