<?php if(isset($respuesta)): ?>
    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($resp->idProfile); ?>">
            <td><?php echo e($resp->user->name); ?></td>
            <td><?php echo e($resp->user->email); ?></td>
            <td><?php echo e($resp->number); ?></td>
            <td><?php echo e($resp->birthday); ?></td>
            <td style="text-align: center;">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo e($resp->idProfile); ?>" style="text-align: center;">
                    Descripción de perfil
                </button>
                <div class="modal fade" id="staticBackdrop<?php echo e($resp->idProfile); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="staticBackdropLabel">Description</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php echo e($resp->description); ?>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                        </div>
                    </div>
                </div>
            </td>
            <td class="button_actions">
                <a href="<?php echo e(route('profiles.edit',$resp->idProfile)); ?>" class="btn btn-success">Editar</a>
                <button class='btnBorrar btn btn-danger' type='submit' form="delete_<?php echo e($resp->idProfile); ?>" onclick="return confirm('¿Estás seguro de eliminar el registro?')">Borrar</button>
                <form action="<?php echo e(route('profiles.destroy',$resp->idProfile)); ?>" method ="POST" id="delete_<?php echo e($resp->idProfile); ?>" enctype="multipart/form-data" hidden><!--method ="POST" -->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/livewire/profile-component.blade.php ENDPATH**/ ?>