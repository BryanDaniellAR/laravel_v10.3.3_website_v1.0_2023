<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Nombre Completo</label>
        <input type="name" class="form-control" name="name" value="<?php echo e((isset($respuesta))?$respuesta->data->name: old('name')); ?>" placeholder="Escribir el nombre completo" maxlength="255" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Email</label>
        <input type="email" class="form-control" name="email" value="<?php echo e((isset($respuesta))?$respuesta->data->email: old('email')); ?>" placeholder="Escribir el email" maxlength="255" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Password</label>
        <input type="password" class="form-control" name="password" value="" placeholder="Escribir el password" maxlength="255" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Role</label>
        <select class="form-select filter-select" name="idRol" title="idRol" required>
            <option value="">Seleccionar un rol</option>
            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->idRol == $respuesta->data->idRol): ?>
                        <option value="<?php echo e($resp->idRol); ?>" selected><?php echo e($resp->description); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->idRol); ?>"><?php echo e($resp->description); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->idRol); ?>"><?php echo e($resp->description); ?></option>
                <?php endif; ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/users/partials/form.blade.php ENDPATH**/ ?>