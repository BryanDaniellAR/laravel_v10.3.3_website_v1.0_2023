
<?php $__env->startSection('content'); ?>
    <div class="card mt-3">
        <div class="card-header d-inline-flex">
            <h5>Rol</h5>
            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary ms-auto" >Agregar</a>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="container-fluid container-tabla">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('role-component')->html();
} elseif ($_instance->childHasBeenRendered('StbeZfj')) {
    $componentId = $_instance->getRenderedChildComponentId('StbeZfj');
    $componentTag = $_instance->getRenderedChildComponentTagName('StbeZfj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('StbeZfj');
} else {
    $response = \Livewire\Livewire::mount('role-component');
    $html = $response->html();
    $_instance->logRenderedChild('StbeZfj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/roles/index.blade.php ENDPATH**/ ?>