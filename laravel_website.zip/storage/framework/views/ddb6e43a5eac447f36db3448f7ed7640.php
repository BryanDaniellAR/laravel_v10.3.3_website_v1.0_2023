<?php if(isset($respuesta)): ?>
    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($resp->idUserHost); ?>">
            <td><?php echo e($resp->user->name); ?>: <?php echo e($resp->user->email); ?></td>
            <td><?php echo e($resp->host->url); ?></td>
            <td class="button_actions">
                <a href="<?php echo e(route('userhosts.edit',$resp->idUserHost)); ?>" class="btn btn-success">Editar</a>
                <button class='btnBorrar btn btn-danger' type='submit' form="delete_<?php echo e($resp->idUserHost); ?>" onclick="return confirm('¿Estás seguro de eliminar el registro?')">Borrar</button>
                <form action="<?php echo e(route('userhosts.destroy',$resp->idUserHost)); ?>" method ="POST" id="delete_<?php echo e($resp->idUserHost); ?>" enctype="multipart/form-data" hidden><!--method ="POST" -->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/livewire/user-host-component.blade.php ENDPATH**/ ?>