
<?php $__env->startSection('content'); ?>
    <div class="card mt-3">
        <div class="card-header d-inline-flex">
            <h5>Image</h5>
            <a href="<?php echo e(route('images.create')); ?>" class="btn btn-primary ms-auto" >Agregar</a>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="container-fluid container-tabla">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Url</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('image-component')->html();
} elseif ($_instance->childHasBeenRendered('liTTRck')) {
    $componentId = $_instance->getRenderedChildComponentId('liTTRck');
    $componentTag = $_instance->getRenderedChildComponentTagName('liTTRck');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('liTTRck');
} else {
    $response = \Livewire\Livewire::mount('image-component');
    $html = $response->html();
    $_instance->logRenderedChild('liTTRck', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Url</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/images/index.blade.php ENDPATH**/ ?>