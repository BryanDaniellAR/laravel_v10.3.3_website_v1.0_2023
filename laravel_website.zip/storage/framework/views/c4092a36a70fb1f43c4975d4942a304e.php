<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Usuario</label>
        <select class="form-select filter-select" name="id" title="id" required>
            <option value="">Seleccionar un usuario</option>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->id == $respuesta->data->id): ?>
                        <option value="<?php echo e($resp->id); ?>" selected><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->id); ?>"><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->id); ?>"><?php echo e($resp->name); ?>: <?php echo e($resp->email); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Host</label>
        <select class="form-select filter-select" name="idHost" title="idHost" required>
            <option value="">Seleccionar un host</option>
            <?php $__currentLoopData = $host; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->idHost == $respuesta->data->idHost): ?>
                        <option value="<?php echo e($resp->idHost); ?>" selected><?php echo e($resp->url); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->idHost); ?>"><?php echo e($resp->url); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->idHost); ?>"><?php echo e($resp->url); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/userhosts/partials/form.blade.php ENDPATH**/ ?>