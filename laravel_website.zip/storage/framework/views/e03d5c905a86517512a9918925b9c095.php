<?php if(isset($respuesta)): ?>
    <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($resp->idImage); ?>">
            <td><?php echo e($resp->name); ?></td>
            <td><?php echo e($resp->url); ?></td>
            <td class="button_actions">
                <?php if(!isset($respuesta)): ?>
                    <a href="<?php echo e(route('images.edit',$resp->idImage)); ?>" class="btn btn-success">Editar</a>
                <?php endif; ?>
                <button class='btnBorrar btn btn-danger' type='submit' form="delete_<?php echo e($resp->idImage); ?>" onclick="return confirm('¿Estás seguro de eliminar el registro?')">Borrar</button>
                <form action="<?php echo e(route('images.destroy',$resp->idImage)); ?>" method ="POST" id="delete_<?php echo e($resp->idImage); ?>" enctype="multipart/form-data" hidden><!--method ="POST" -->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/livewire/image-component.blade.php ENDPATH**/ ?>