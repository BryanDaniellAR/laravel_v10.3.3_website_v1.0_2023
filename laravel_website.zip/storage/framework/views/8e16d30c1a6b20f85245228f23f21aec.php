<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-12"><div class="form-group">
        <label form="">Name</label>
        <input type="text" class="form-control" name="name" value="<?php echo e((isset($respuesta))?$respuesta->data->name: old('name')); ?>" placeholder="Escribir la name" maxlength="100" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Url</label>
        <input type="text" class="form-control" name="url" value="<?php echo e((isset($respuesta))?$respuesta->data->url: old('url')); ?>" placeholder="Escribir la url" maxlength="200" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Description</label>
        <textarea type="text" class="form-control" name="description" aria-label="With textarea" placeholder="Escribir la description" maxlength="500" rows="4" required><?php echo e((isset($respuesta))?$respuesta->data->description: old('description')); ?></textarea>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">UrlOptional</label>
        <input type="text" class="form-control" name="urlOptional" value="<?php echo e((isset($respuesta))?$respuesta->data->urlOptional: old('urlOptional')); ?>" placeholder="Escribir la urlOptional" maxlength="200" required>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Usability</label>
        <select class="form-select filter-select" name="idUsability" title="idUsability" required>
            <option value="">Seleccionar un uso</option>
            <?php $__currentLoopData = $usability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->idUsability == $respuesta->data->idUsability): ?>
                        <option value="<?php echo e($resp->idUsability); ?>" selected><?php echo e($resp->name); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->idUsability); ?>"><?php echo e($resp->name); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->idUsability); ?>"><?php echo e($resp->name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Usuario</label>
        <select class="form-select filter-select" name="idUserHost" title="idUserHost" required>
            <option value="">Seleccionar un usuario</option>
            <?php $__currentLoopData = $userhost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($respuesta)): ?>
                    <?php if($resp->idUserHost == $respuesta->data->idUserHost): ?>
                        <option value="<?php echo e($resp->idUserHost); ?>" selected><?php echo e($resp->user->name); ?>: <?php echo e($resp->user->email); ?></option>
                    <?php else: ?>{
                        <option value="<?php echo e($resp->idUserHost); ?>"><?php echo e($resp->user->name); ?>: <?php echo e($resp->user->email); ?></option>
                    }
                    <?php endif; ?>
                <?php else: ?>
                    <option value="<?php echo e($resp->idUserHost); ?>"><?php echo e($resp->user->name); ?>: <?php echo e($resp->user->email); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12"><div class="form-group">
        <label form="">Position</label>
        <input type="number" class="form-control" name="position" value="<?php echo e((isset($respuesta))?$respuesta->data->position: old('position')); ?>" placeholder="Escribir la position" maxlength="3">
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/files/partials/form.blade.php ENDPATH**/ ?>