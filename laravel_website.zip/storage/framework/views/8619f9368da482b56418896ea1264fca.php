

<?php $__env->startSection('login'); ?>

<!--<h2 style="color:white;justify-content: center;display: flex; font-size:3vh;">LOG IN</h2>-->
<div id="fondo">
    <div class="contenedor row">
        <div class="card-header" style="text-align: center;">
            <img src="<?php echo e(URL::asset('img/logo_login.png')); ?>" id="logo_login" title="logo_login">
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('login')); ?>">
            <!--<form method="POST" action="/usuario">-->
                <?php echo csrf_field(); ?>

                <div class="row mb-3">
                    <!--<label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>-->

                    <div class="col-md-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><ion-icon name="mail"></ion-icon></span>
                            <input id="email" type="email" class="form-control inputLogin <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Correo institucional" autofocus>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <!--<label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>-->

                    <div class="col-md-12">
                        <div class="input-group mb-3">
                            <span class="input-group-text" id="basic-addon1"><ion-icon name="lock-closed"></ion-icon></span>
                            <input id="password" type="password" class="form-control inputLogin <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-12">
                    <div class="col-md-12 offset-md-12">
                        <div class="container">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" style="color:white;" for="remember">
                                    <?php echo e(__('Remember Me')); ?>

                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12" style="
                    align-items: center;
                    display: flex;
                    justify-content: center;
                ">
                    <button type="submit" class="btn btn-primary buttonLogin">
                        <?php echo e(__('Log in')); ?>

                    </button>
                </div>
                
            </form>
        </div>
        <div class="card-footer" style="text-align: center;">
            <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" style="color:white;" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('Forgot Your Password?')); ?>

                </a>
            <?php endif; ?>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/auth/login.blade.php ENDPATH**/ ?>