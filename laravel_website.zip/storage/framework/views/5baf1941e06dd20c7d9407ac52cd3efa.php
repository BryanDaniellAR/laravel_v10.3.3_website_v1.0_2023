
<?php $__env->startSection('content'); ?>
    <div class="card mt-3">
        <div class="card-header d-inline-flex">
            <h5>User</h5>
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary ms-auto" >Agregar</a>
        </div>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="container-fluid container-tabla">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-component')->html();
} elseif ($_instance->childHasBeenRendered('zaMXeHf')) {
    $componentId = $_instance->getRenderedChildComponentId('zaMXeHf');
    $componentTag = $_instance->getRenderedChildComponentTagName('zaMXeHf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zaMXeHf');
} else {
    $response = \Livewire\Livewire::mount('user-component');
    $html = $response->html();
    $_instance->logRenderedChild('zaMXeHf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_website\resources\views/users/index.blade.php ENDPATH**/ ?>