<?php return array (
  'c-b-usability-component' => 'App\\Http\\Livewire\\CBUsabilityComponent',
  'c-b-usuario-component' => 'App\\Http\\Livewire\\CBUsuarioComponent',
  'file-component' => 'App\\Http\\Livewire\\FileComponent',
  'host-component' => 'App\\Http\\Livewire\\HostComponent',
  'image-component' => 'App\\Http\\Livewire\\ImageComponent',
  'profile-component' => 'App\\Http\\Livewire\\ProfileComponent',
  'role-component' => 'App\\Http\\Livewire\\RoleComponent',
  'usability-component' => 'App\\Http\\Livewire\\UsabilityComponent',
  'user-component' => 'App\\Http\\Livewire\\UserComponent',
  'user-host-component' => 'App\\Http\\Livewire\\UserHostComponent',
);